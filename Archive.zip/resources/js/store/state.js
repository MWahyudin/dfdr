//to handle state
const state = {
  users: [],
  json: {}
};
