<template>
  <div class="width-page" style="width:80%;">
    <header-component></header-component>
    <div style="margin-bottom: 0px;">
      <router-view></router-view>
    </div>
    <footer-component></footer-component>
  </div>
</template>
