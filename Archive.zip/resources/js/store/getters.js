//to handle state
const getters = {
  getAllUsers: (state) => state.users,
};
