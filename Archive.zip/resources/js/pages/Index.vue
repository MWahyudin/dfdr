<template>
  <div class="width-page">
    <header-component></header-component>
    <div style="margin-bottom: 50px;">
      <router-view></router-view>
    </div>
    <footer-component></footer-component>
  </div>
</template>
