<?php

namespace App\Models\Template;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ContentGuidelane extends Model
{
    use HasFactory;
    protected $table = 'temp_submission_content_guidelane';

}
